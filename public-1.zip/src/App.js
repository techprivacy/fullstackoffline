import { useEffect, useState } from "react";
import LoginRoute from "./loginRoute.js";
import Routing from "./routing.js";

function App() {

const [Auth, setAuth] =useState(false)
useEffect(()=>{
  console.log(localStorage.getItem('auth'))
})

  return (
    <>
{localStorage.getItem('auth')==='Success' ?

<Routing/>

:
<LoginRoute/>

}
</>

  );
}

export default App;
