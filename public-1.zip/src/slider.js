function Slider() {

    return (

  <h1>Slider comp</h1>


    );
  }


export default Slider;

