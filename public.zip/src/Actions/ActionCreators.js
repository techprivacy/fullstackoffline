import { SET_COUNT } from "./Types";

export const setCount =(data) =>({
type: SET_COUNT,
data
})