import { setCount } from "./ActionCreators";


export const setCountDemo=(data)=>{
return(dispatch)=>{
    dispatch(setCount(data))
}

}
