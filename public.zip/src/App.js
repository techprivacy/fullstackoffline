import Routing from "./routing.js";

function App() {

  return (
<Routing/>
  );
}

export default App;
