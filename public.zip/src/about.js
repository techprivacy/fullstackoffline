import React from 'react'

export default function About() {
  return (
    <div>About us page</div>
  )
}
