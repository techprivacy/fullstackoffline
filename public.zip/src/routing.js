import React from "react";
import { Routes, Route } from "react-router-dom";
import About from "./about";
import Contact from "./contact";
import Navigation from "./navigation";

export default function Routing() {
  return (
    <>
      <Navigation />
      <Routes>
        <Route path="/About" element={<About />} />
        <Route path="/Contact" element={<Contact />} />
      </Routes>
    </>
  );
}
