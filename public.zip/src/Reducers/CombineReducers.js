import {combineReducers} from 'redux'
import MyCount from './Count'

export default combineReducers({MyCount});
