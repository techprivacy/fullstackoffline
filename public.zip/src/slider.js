function Slider() {

    return (

  <h1>Slider</h1>


    );
  }


export default Slider;

