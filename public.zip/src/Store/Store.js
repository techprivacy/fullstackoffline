import { createStore, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import rootReducer from "../Reducers/CombineReducers";

const persistState =  
localStorage.getItem('reduxStore') ? 
JSON.parse(localStorage.getItem('reduxStore'))
: {}

const store = createStore(rootReducer, persistState, applyMiddleware(thunk));

export default store;
